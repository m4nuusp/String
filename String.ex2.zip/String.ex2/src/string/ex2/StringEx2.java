/*
2 - Crie um programa que informa a quantidade de vogais de uma frase informada pelo
usuário;
 */
package string.ex2;

import java.util.Scanner;

public class StringEx2 {

    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       String frase, frasem;
       int cont =0, tamanhofrase, tamanhofrase2, resp;
       
        System.out.println("Digite uma frase:");
        frase = teclado.nextLine();
        tamanhofrase = frase.length();
        frasem = frase.toLowerCase();
        
        for (int i = 0; i < tamanhofrase; i++) {
           char c = frasem.charAt(i);
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                cont++;
                
            }
        } System.out.println(cont);
     
    }
}
