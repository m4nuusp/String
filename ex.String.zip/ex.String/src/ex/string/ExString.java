/*
 1 – Crie um programa que informa a quantidade de caracteres de uma frase informada
pelo usuário; */
package ex.string;

import java.util.Scanner;

public class ExString {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String frase;
        int tam;
        System.out.println("Digite uma frase");
       frase = teclado.nextLine();
       tam = frase.length();
        System.out.println( tam);
    }
    
}
