/*
 3 - Crie um programa que informa a quantidade de palavras de uma frase informada pelo
usuário;
 */
package string.ex3;

import java.util.Scanner;

public class StringEx3 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String frase;
        int resp;
        
        System.out.println("Informe uma frase:");
        frase = teclado.nextLine();
      
       String frase2[] = frase.split(" ");
       resp = frase2.length;
        System.out.println("A quantidade de palavras e " + resp);
 
          
    }
    
}
