/*
 6 – Crie um programa onde o usuário informa o nome completo de uma pessoa. Monte
em uma nova variável e apresente o sobre-nome seguido de vírgula e os demais nomes.
Exemplo: Paulo Eduardo Marcondes Silva → Silva, Paulo Eduardo Marcondes
 */
package string.ex6;

import java.util.Scanner;

public class StringEx6 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        String nome, sobrenome;
        int posicao = 0;
        
        System.out.println("Digite seu nome completo:");
        nome = teclado.nextLine();
        
        for (int i = 0; i < nome.length(); i++) {
            if (nome.charAt(i) == ' ') {
                posicao = i;
            }           
        }
        sobrenome = nome.substring(posicao, nome.length());
        
        System.out.println(sobrenome + ", " + nome.substring(0, posicao));

    }
    
}
