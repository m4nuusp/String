/*
 4 – Crie um programa que apresenta o primeiro nome de um nome completo de uma
pessoa que foi digitado pelo usuário;
 */
package string.ex4;

import java.util.Scanner;

public class StringEx4 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        String nomecompleto, nome;
        int caracter, tam;
        
        System.out.println("Digite seu nome completo:");
        nomecompleto = teclado.nextLine();
       
        caracter = nomecompleto.indexOf(' ');
        nome = nomecompleto.substring(0,caracter);
        
        System.out.println(nome);
        
        
    }
    
}
