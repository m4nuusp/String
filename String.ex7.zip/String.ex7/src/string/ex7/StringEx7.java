/*
 7 – Crie um programa onde o usuário informa o nome completo de uma pessoa. Monte
em uma nova variável e apresenta esse nome com os nomes do meio abreviados.
Ex. Paulo Eduardo Marcondes Silva → Paulo E. M. Silva
 */
package string.ex7;

import java.util.Scanner;

public class StringEx7 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        String nome, nomeAbreviado = "";
        int inicio = 0, fim;

        System.out.println("Digite o nome completo:");
        nome = teclado.nextLine();

        fim = nome.indexOf(" ");

        nomeAbreviado = nome.substring(0, fim) + " ";
        inicio = fim + 1;

        while (nome.indexOf(" ", inicio) != -1) {
            fim = nome.indexOf(" ", inicio);

            nomeAbreviado = nomeAbreviado + nome.charAt(inicio) + ". ";

            inicio = fim + 1;
        }

        nomeAbreviado = nomeAbreviado + nome.substring(inicio);

        System.out.println(nomeAbreviado);

    }
    
}
