/*
 5 - Crie um programa informa o próximo ano de uma data informada no formato
“dd/mm/aaaa” ou “dd/mm/aa”
 */
package string.ex5;

import java.util.Scanner;

public class StringEx5 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String data;
        String dia, mes, ano;
        
        System.out.println("Digite uma data no formato dd/mm/aaaa ou dd/mm/aa");
        data = teclado.nextLine();
        
         dia = data.substring(0, 2);
         mes = data.substring(3, 5);
         
         if (data.length()==10) {
             ano = data.substring(6, 10);
        } else {
              ano = data.substring(6, 8);
         }
         int anonovo = Integer.parseInt(ano);
         anonovo = anonovo +1;
         
         System.out.println("A data nova é: " + dia + "/" + mes + "/" + anonovo);
        
    }
    
}
